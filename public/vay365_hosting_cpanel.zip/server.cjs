var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_nodemailer = __toESM(require("nodemailer"), 1);
var import_vite = require("vite");
import_dotenv.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json());
app.use(import_express.default.urlencoded({ extended: true }));
var DATA_DIR = import_path.default.join(process.cwd(), "data");
var LEADS_FILE = import_path.default.join(DATA_DIR, "leads_db.json");
var CONFIG_FILE = import_path.default.join(DATA_DIR, "config_db.json");
var DEFAULT_ADMIN_EMAIL = process.env.ADMIN_NOTIFICATION_EMAIL || "phamduchai6991@gmail.com";
function initStorage() {
  if (!import_fs.default.existsSync(DATA_DIR)) {
    import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!import_fs.default.existsSync(LEADS_FILE)) {
    const initialLeads = [
      {
        id: "LEAD-9082",
        fullName: "Nguy\u1EC5n V\u0103n H\xF9ng",
        phone: "0912345678",
        province: "Ngh\u1EC7 An",
        loanAmount: 8e7,
        loanTenure: 24,
        loanPurpose: "tin_chap_theo_luong",
        loanPurposeName: "Vay T\xEDn Ch\u1EA5p Theo B\u1EA3ng L\u01B0\u01A1ng",
        monthlyIncome: 18e6,
        preferredContactTime: "Bu\u1ED5i s\xE1ng (8h - 12h)",
        note: "Nh\u1EADn l\u01B0\u01A1ng chuy\u1EC3n kho\u1EA3n Vietcombank 18tr/th\xE1ng, c\u1EA7n vay t\xEDn ch\u1EA5p s\u1EEDa sang nh\xE0",
        createdAt: "2026-08-21T08:30:00Z",
        status: "new",
        source: "C\xF4ng c\u1EE5 t\xEDnh l\xE3i"
      },
      {
        id: "LEAD-8741",
        fullName: "Tr\u1EA7n Th\u1ECB Mai Ph\u01B0\u01A1ng",
        phone: "0987654321",
        province: "H\xE0 N\u1ED9i",
        loanAmount: 5e7,
        loanTenure: 18,
        loanPurpose: "tin_chap_tieu_dung",
        loanPurposeName: "Vay T\xEDn Ch\u1EA5p Ti\xEAu D\xF9ng C\xE1 Nh\xE2n",
        monthlyIncome: 15e6,
        preferredContactTime: "B\u1EA5t k\u1EF3 l\xFAc n\xE0o",
        note: "Vay t\xEDn ch\u1EA5p ti\xEAu d\xF9ng c\xE1 nh\xE2n kh\xF4ng th\u1EBF ch\u1EA5p",
        createdAt: "2026-08-21T04:15:00Z",
        status: "contacted",
        adminNote: "\u0110\xE3 g\u1ECDi t\u01B0 v\u1EA5n, kh\xE1ch h\u1EB9n g\u1EEDi sao k\xEA l\u01B0\u01A1ng qua Zalo chi\u1EC1u nay",
        source: "Form trang ch\u1EE7"
      },
      {
        id: "LEAD-7319",
        fullName: "L\xEA Ho\xE0ng Nam",
        phone: "0903456789",
        province: "TP. H\u1ED3 Ch\xED Minh",
        loanAmount: 1e8,
        loanTenure: 36,
        loanPurpose: "tin_chap_kinh_doanh",
        loanPurposeName: "Vay T\xEDn Ch\u1EA5p H\u1ED9 Kinh Doanh",
        monthlyIncome: 3e7,
        preferredContactTime: "Bu\u1ED5i chi\u1EC1u (13h30 - 17h30)",
        note: "Kinh doanh c\u1EEDa h\xE0ng t\u1EA1p h\xF3a, c\u1EA7n v\u1ED1n nh\u1EADp h\xE0ng kh\xF4ng th\u1EBF ch\u1EA5p",
        createdAt: "2026-08-20T14:40:00Z",
        status: "approved",
        adminNote: "\u0110\xE3 duy\u1EC7t h\u1ED3 s\u01A1 t\xEDn ch\u1EA5p 100tr k\u1EF3 h\u1EA1n 36 th\xE1ng",
        source: "G\xF3i vay t\xEDn ch\u1EA5p KD"
      }
    ];
    import_fs.default.writeFileSync(LEADS_FILE, JSON.stringify(initialLeads, null, 2), "utf-8");
  }
  if (!import_fs.default.existsSync(CONFIG_FILE)) {
    const initialConfig = {
      adminEmail: DEFAULT_ADMIN_EMAIL
    };
    import_fs.default.writeFileSync(CONFIG_FILE, JSON.stringify(initialConfig, null, 2), "utf-8");
  }
}
function getStoredLeads() {
  try {
    initStorage();
    const data = import_fs.default.readFileSync(LEADS_FILE, "utf-8");
    return JSON.parse(data);
  } catch (err) {
    console.error("Error reading leads:", err);
    return [];
  }
}
function saveStoredLeads(leads) {
  try {
    initStorage();
    import_fs.default.writeFileSync(LEADS_FILE, JSON.stringify(leads, null, 2), "utf-8");
    return true;
  } catch (err) {
    console.error("Error writing leads:", err);
    return false;
  }
}
function getStoredConfig() {
  try {
    initStorage();
    const data = import_fs.default.readFileSync(CONFIG_FILE, "utf-8");
    return JSON.parse(data);
  } catch (err) {
    return {
      adminEmail: DEFAULT_ADMIN_EMAIL
    };
  }
}
async function triggerEmailNotification(lead, recipient = DEFAULT_ADMIN_EMAIL) {
  const formattedAmount = new Intl.NumberFormat("vi-VN").format(lead.loanAmount || 0);
  const formattedIncome = lead.monthlyIncome ? new Intl.NumberFormat("vi-VN").format(lead.monthlyIncome) + " VN\u0110" : "Ch\u01B0a cung c\u1EA5p";
  const cleanPhone = String(lead.phone || "").trim();
  const textContent = `
TH\xD4NG B\xC1O H\u1ED2 S\u01A0 VAY T\xCDN CH\u1EA4P M\u1EDAI T\u1EEA WEBSITE VAY365
==================================================
H\u1ECD v\xE0 t\xEAn kh\xE1ch h\xE0ng: ${lead.fullName}
S\u1ED1 \u0111i\u1EC7n tho\u1EA1i: ${cleanPhone}
S\u1ED1 ti\u1EC1n \u0111\u0103ng k\xFD vay: ${formattedAmount} VN\u0110
K\u1EF3 h\u1EA1n vay mong mu\u1ED1n: ${lead.loanTenure} th\xE1ng (${(lead.loanTenure / 12).toFixed(1)} n\u0103m)
G\xF3i vay / Nhu c\u1EA7u: ${lead.loanPurposeName || lead.loanPurpose}
Ngh\u1EC1 nghi\u1EC7p: ${lead.occupation || "Ch\u01B0a cung c\u1EA5p"}
Thu nh\u1EADp h\xE0ng th\xE1ng: ${formattedIncome}
T\u1EC9nh / Th\xE0nh ph\u1ED1: ${lead.province || "Ch\u01B0a cung c\u1EA5p"}
Ghi ch\xFA t\u1EEB kh\xE1ch: ${lead.notes || lead.note || "Kh\xF4ng c\xF3 ghi ch\xFA th\xEAm"}
Th\u1EDDi gian g\u1EEDi: ${lead.createdAt || (/* @__PURE__ */ new Date()).toLocaleString("vi-VN")}
M\xE3 h\u1ED3 s\u01A1 (Lead ID): ${lead.id}

H\xE0nh \u0111\u1ED9ng nhanh:
- G\u1ECDi \u0111i\u1EC7n ngay: tel:${cleanPhone}
- Nh\u1EAFn Zalo: https://zalo.me/${cleanPhone}
==================================================
H\u1EC7 th\u1ED1ng Qu\u1EA3n Tr\u1ECB Website \u0110\u1EE9c H\u1EA3i FE - Vay365 (Hotline: 0583.345.345)
\u0110\u1ECBa ch\u1EC9 nh\u1EADn: ${recipient}
`.trim();
  const htmlContent = `
    <!DOCTYPE html>
    <html lang="vi">
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f1f5f9; margin: 0; padding: 20px; color: #1e293b; }
        .card { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08); border: 1px solid #e2e8f0; }
        .header { background: linear-gradient(135deg, #065f46 0%, #047857 100%); color: #ffffff; padding: 24px; text-align: center; }
        .header h1 { margin: 0; font-size: 20px; font-weight: 800; letter-spacing: -0.5px; }
        .header p { margin: 6px 0 0; font-size: 13px; color: #a7f3d0; }
        .badge { display: inline-block; background: #fbbf24; color: #78350f; font-size: 11px; font-weight: 800; padding: 4px 10px; border-radius: 9999px; margin-top: 10px; text-transform: uppercase; }
        .body-content { padding: 24px; }
        .info-table { width: 100%; border-collapse: collapse; margin-top: 12px; }
        .info-table tr { border-bottom: 1px solid #f1f5f9; }
        .info-table td { padding: 10px 8px; font-size: 13px; }
        .info-table td.label { font-weight: 600; color: #64748b; width: 38%; }
        .info-table td.val { font-weight: 700; color: #0f172a; }
        .highlight-val { color: #047857; font-size: 16px; font-weight: 800; }
        .phone-val { color: #2563eb; font-size: 15px; font-weight: 800; text-decoration: none; }
        .action-box { margin-top: 24px; text-align: center; padding: 18px; background: #ecfdf5; border-radius: 12px; border: 1px solid #a7f3d0; }
        .btn-call { display: inline-block; background: #059669; color: #ffffff; text-decoration: none; font-weight: 800; font-size: 14px; padding: 12px 28px; border-radius: 10px; margin: 6px 4px; box-shadow: 0 2px 6px rgba(5,150,105,0.3); }
        .btn-zalo { display: inline-block; background: #0284c7; color: #ffffff; text-decoration: none; font-weight: 800; font-size: 14px; padding: 12px 28px; border-radius: 10px; margin: 6px 4px; box-shadow: 0 2px 6px rgba(2,132,199,0.3); }
        .footer { background: #f8fafc; padding: 16px; text-align: center; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; }
      </style>
    </head>
    <body>
      <div class="card">
        <div class="header">
          <h1>\u{1F514} C\xD3 KH\xC1CH H\xC0NG M\u1EDAI \u0110\u0102NG K\xDD VAY</h1>
          <p>H\u1EC7 th\u1ED1ng Vay365 - \u0110\u1EE9c H\u1EA3i FE ghi nh\u1EADn h\u1ED3 s\u01A1 vay t\xEDn ch\u1EA5p tr\u1EF1c tuy\u1EBFn</p>
          <div class="badge">H\u1ED3 S\u01A1 M\u1EDBi Ch\u1EDD Li\xEAn H\u1EC7</div>
        </div>

        <div class="body-content">
          <table class="info-table">
            <tr>
              <td class="label">H\u1ECD v\xE0 t\xEAn kh\xE1ch:</td>
              <td class="val highlight-val">${lead.fullName}</td>
            </tr>
            <tr>
              <td class="label">S\u1ED1 \u0111i\u1EC7n tho\u1EA1i:</td>
              <td class="val"><a href="tel:${cleanPhone}" class="phone-val">\u{1F4DE} ${cleanPhone} (B\u1EA5m \u0111\u1EC3 g\u1ECDi)</a></td>
            </tr>
            <tr>
              <td class="label">S\u1ED1 ti\u1EC1n \u0111\u0103ng k\xFD vay:</td>
              <td class="val highlight-val">${formattedAmount} VN\u0110</td>
            </tr>
            <tr>
              <td class="label">K\u1EF3 h\u1EA1n mong mu\u1ED1n:</td>
              <td class="val">${lead.loanTenure} th\xE1ng (${(lead.loanTenure / 12).toFixed(1)} n\u0103m)</td>
            </tr>
            <tr>
              <td class="label">G\xF3i vay / Nhu c\u1EA7u:</td>
              <td class="val">${lead.loanPurposeName || lead.loanPurpose}</td>
            </tr>
            <tr>
              <td class="label">Ngh\u1EC1 nghi\u1EC7p:</td>
              <td class="val">${lead.occupation || "Ch\u01B0a cung c\u1EA5p"}</td>
            </tr>
            <tr>
              <td class="label">Thu nh\u1EADp h\xE0ng th\xE1ng:</td>
              <td class="val">${formattedIncome}</td>
            </tr>
            <tr>
              <td class="label">T\u1EC9nh / Th\xE0nh ph\u1ED1:</td>
              <td class="val">${lead.province || "Ch\u01B0a cung c\u1EA5p"}</td>
            </tr>
            <tr>
              <td class="label">Ghi ch\xFA t\u1EEB kh\xE1ch:</td>
              <td class="val">${lead.notes || lead.note || "Kh\xF4ng c\xF3 ghi ch\xFA th\xEAm"}</td>
            </tr>
            <tr>
              <td class="label">Th\u1EDDi gian g\u1EEDi:</td>
              <td class="val">${lead.createdAt || (/* @__PURE__ */ new Date()).toLocaleString("vi-VN")}</td>
            </tr>
            <tr>
              <td class="label">M\xE3 Lead:</td>
              <td class="val"><code>${lead.id}</code></td>
            </tr>
          </table>

          <div class="action-box">
            <p style="margin: 0 0 10px 0; font-size: 13px; color: #065f46; font-weight: 600;">H\xE3y li\xEAn h\u1EC7 t\u01B0 v\u1EA5n v\xE0 gi\u1EA3i \u0111\xE1p cho kh\xE1ch h\xE0ng s\u1EDBm nh\u1EA5t!</p>
            <a href="tel:${cleanPhone}" class="btn-call">\u{1F4DE} G\u1ECCI NGAY: ${cleanPhone}</a>
            <a href="https://zalo.me/${cleanPhone}" class="btn-zalo" target="_blank">\u{1F4AC} NH\u1EAEN ZALO</a>
          </div>
        </div>

        <div class="footer">
          Email th\xF4ng b\xE1o t\u1EF1 \u0111\u1ED9ng t\u1EEB website <strong>\u0110\u1EE9c H\u1EA3i FE - T\u01B0 V\u1EA5n Vay T\xEDn Ch\u1EA5p &amp; L\xE3i Su\u1EA5t D\u01B0 N\u1EE3 Gi\u1EA3m D\u1EA7n</strong><br/>
          H\u1ED9p th\u01B0 nh\u1EADn: <strong>${recipient}</strong> | Hotline h\u1ED7 tr\u1EE3: <strong>0583.345.345</strong>
        </div>
      </div>
    </body>
    </html>
  `;
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  const smtpHost = process.env.SMTP_HOST || "smtp.gmail.com";
  const smtpPort = Number(process.env.SMTP_PORT) || 587;
  if (smtpUser && smtpPass) {
    try {
      const transporter = import_nodemailer.default.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465,
        auth: { user: smtpUser, pass: smtpPass },
        connectionTimeout: 15e3,
        greetingTimeout: 1e4,
        socketTimeout: 2e4
      });
      const sendInfo = await transporter.sendMail({
        from: `"Vay365 - \u0110\u1EE9c H\u1EA3i FE" <${smtpUser}>`,
        to: recipient,
        replyTo: recipient,
        subject: `\u{1F525} [VAY365] Kh\xE1ch m\u1EDBi: ${lead.fullName} (${cleanPhone}) - Vay ${formattedAmount}\u0111`,
        text: textContent,
        html: htmlContent,
        headers: {
          "X-Priority": "1",
          "X-MSMail-Priority": "High",
          "Importance": "high"
        }
      });
      console.log(`\u2705 SMTP email sent successfully for ${lead.id} to ${recipient}, messageId: ${sendInfo.messageId}`);
      return { success: true, method: "server_smtp", messageId: sendInfo.messageId };
    } catch (smtpErr) {
      console.warn("SMTP send error, falling back to relay:", smtpErr?.message || smtpErr);
    }
  }
  try {
    const formData = new URLSearchParams();
    formData.append("_subject", `\u{1F525} [VAY365] Kh\xE1ch m\u1EDBi: ${lead.fullName} (${cleanPhone}) - Vay ${formattedAmount}\u0111`);
    formData.append("_replyto", recipient);
    formData.append("_captcha", "false");
    formData.append("_template", "table");
    formData.append("H\u1ECD v\xE0 T\xEAn", lead.fullName);
    formData.append("S\u1ED1 \u0110i\u1EC7n Tho\u1EA1i", cleanPhone);
    formData.append("S\u1ED1 Ti\u1EC1n Vay", `${formattedAmount} VN\u0110`);
    formData.append("K\u1EF3 H\u1EA1n Vay", `${lead.loanTenure} th\xE1ng`);
    formData.append("G\xF3i Vay", lead.loanPurposeName || lead.loanPurpose);
    formData.append("Ngh\u1EC1 Nghi\u1EC7p", lead.occupation || "Ch\u01B0a cung c\u1EA5p");
    formData.append("Thu Nh\u1EADp", formattedIncome);
    formData.append("T\u1EC9nh / Th\xE0nh", lead.province || "Ch\u01B0a cung c\u1EA5p");
    formData.append("Ghi Ch\xFA", lead.notes || lead.note || "Kh\xF4ng");
    formData.append("M\xE3 H\u1ED3 S\u01A1", lead.id);
    const relayRes = await fetch(`https://formsubmit.co/ajax/${encodeURIComponent(recipient)}`, {
      method: "POST",
      body: formData,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/x-www-form-urlencoded"
      }
    });
    if (relayRes.ok) {
      const relayJson = await relayRes.json().catch(() => ({}));
      if (relayJson.success !== false) {
        return { success: true, method: "relay_service" };
      }
    }
  } catch (relayErr) {
    console.error("Relay error:", relayErr?.message || relayErr);
  }
  return { success: false, method: "failed" };
}
app.get("/api/health", (req, res) => {
  const config = getStoredConfig();
  res.json({
    status: "ok",
    adminEmail: config.adminEmail || DEFAULT_ADMIN_EMAIL,
    smtpConfigured: Boolean(process.env.SMTP_USER && process.env.SMTP_PASS),
    smtpUser: process.env.SMTP_USER || null,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.get("/api/smtp/verify", async (req, res) => {
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  const smtpHost = process.env.SMTP_HOST || "smtp.gmail.com";
  const smtpPort = Number(process.env.SMTP_PORT) || 587;
  if (!smtpUser || !smtpPass) {
    return res.status(400).json({
      success: false,
      message: "Ch\u01B0a c\u1EA5u h\xECnh t\xE0i kho\u1EA3n SMTP (SMTP_USER ho\u1EB7c SMTP_PASS thi\u1EBFu)"
    });
  }
  try {
    const transporter = import_nodemailer.default.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: smtpPort === 465,
      auth: { user: smtpUser, pass: smtpPass },
      connectionTimeout: 1e4
    });
    await transporter.verify();
    return res.json({
      success: true,
      message: `K\u1EBFt n\u1ED1i th\xE0nh c\xF4ng t\u1EDBi m\xE1y ch\u1EE7 Gmail SMTP (${smtpUser})`,
      host: smtpHost,
      port: smtpPort
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: `L\u1ED7i k\u1EBFt n\u1ED1i Gmail SMTP: ${err?.message || err}`
    });
  }
});
app.get("/api/leads", (req, res) => {
  const leads = getStoredLeads();
  if (req.query.export === "excel" || req.query.export === "csv") {
    const headers = [
      "M\xE3 H\u1ED3 S\u01A1",
      "Th\u1EDDi Gian G\u1EEDi",
      "H\u1ECD V\xE0 T\xEAn",
      "S\u1ED1 \u0110i\u1EC7n Tho\u1EA1i",
      "S\u1ED1 Ti\u1EC1n Vay (VN\u0110)",
      "K\u1EF3 H\u1EA1n (Th\xE1ng)",
      "G\xF3i Vay / M\u1EE5c \u0110\xEDch",
      "Thu Nh\u1EADp H\xE0ng Th\xE1ng",
      "T\u1EC9nh / Th\xE0nh Ph\u1ED1",
      "Tr\u1EA1ng Th\xE1i",
      "Ghi Ch\xFA Kh\xE1ch",
      "Ghi Ch\xFA Qu\u1EA3n Tr\u1ECB"
    ];
    const escapeCSV = (val) => {
      if (val === void 0 || val === null) return '""';
      const clean = String(val).replace(/"/g, '""');
      return `"${clean}"`;
    };
    const getStatusText = (status) => {
      switch (status) {
        case "new":
          return "Ch\u01B0a g\u1ECDi (M\u1EDBi)";
        case "contacted":
          return "\u0110\xE3 li\xEAn h\u1EC7 t\u01B0 v\u1EA5n";
        case "approved":
          return "\u0110\xE3 duy\u1EC7t gi\u1EA3i ng\xE2n";
        case "rejected":
          return "T\u1EEB ch\u1ED1i";
        default:
          return status || "M\u1EDBi";
      }
    };
    const rows = leads.map((lead) => [
      escapeCSV(lead.id || ""),
      escapeCSV(lead.createdAt || ""),
      escapeCSV(lead.fullName || ""),
      escapeCSV(`'${lead.phone || ""}`),
      escapeCSV(new Intl.NumberFormat("vi-VN").format(lead.loanAmount || 0)),
      escapeCSV(lead.loanTenure || 24),
      escapeCSV(lead.loanPurposeName || lead.loanPurpose || "Vay T\xEDn Ch\u1EA5p"),
      escapeCSV(lead.monthlyIncome ? new Intl.NumberFormat("vi-VN").format(Number(lead.monthlyIncome) || 0) : "Kh\xF4ng khai b\xE1o"),
      escapeCSV(lead.province || "Ch\u01B0a cung c\u1EA5p"),
      escapeCSV(getStatusText(lead.status)),
      escapeCSV(lead.notes || lead.note || ""),
      escapeCSV(lead.adminNote || "")
    ]);
    const csvData = "\uFEFF" + [headers.join(","), ...rows.map((r) => r.join(","))].join("\r\n");
    const filename = `Vay365_Danh_Sach_Ho_So_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    return res.status(200).send(csvData);
  }
  res.json({ success: true, total: leads.length, leads });
});
var recentServerSubmissions = /* @__PURE__ */ new Map();
app.post("/api/leads", async (req, res) => {
  const payload = req.body || {};
  const leadData = payload.lead || payload;
  const honeypotWebsite = payload.hp_website || leadData.hp_website || payload.hp_company;
  if (honeypotWebsite && String(honeypotWebsite).trim().length > 0) {
    console.warn("\u{1F6E1}\uFE0F Bot trapped in honeypot on server:", honeypotWebsite);
    return res.status(200).json({ success: true, message: "\u0110\xE3 nh\u1EADn h\u1ED3 s\u01A1" });
  }
  if (payload.captchaExpected !== void 0 && payload.captchaAnswer !== void 0) {
    if (Number(payload.captchaAnswer) !== Number(payload.captchaExpected)) {
      return res.status(400).json({
        success: false,
        message: "C\xE2u tr\u1EA3 l\u1EDDi ch\u1ED1ng spam kh\xF4ng ch\xEDnh x\xE1c. Vui l\xF2ng ki\u1EC3m tra l\u1EA1i ph\xE9p t\xEDnh."
      });
    }
  }
  if (!leadData || !leadData.fullName || !leadData.phone) {
    return res.status(400).json({ success: false, message: "D\u1EEF li\u1EC7u kh\xE1ch h\xE0ng kh\xF4ng h\u1EE3p l\u1EC7" });
  }
  const cleanPhone = String(leadData.phone || "").replace(/\D/g, "");
  const vnPhoneRegex = /^(03|05|07|08|09)\d{8}$/;
  if (!vnPhoneRegex.test(cleanPhone)) {
    return res.status(400).json({
      success: false,
      message: "S\u1ED1 \u0111i\u1EC7n tho\u1EA1i kh\xF4ng h\u1EE3p l\u1EC7 theo chu\u1EA9n vi\u1EC5n th\xF4ng Vi\u1EC7t Nam (10 s\u1ED1, \u0111\u1EA7u 03, 05, 07, 08, 09)"
    });
  }
  const clientIp = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "unknown";
  const now = Date.now();
  const phoneKey = `phone:${cleanPhone}`;
  if (recentServerSubmissions.has(phoneKey) && now - recentServerSubmissions.get(phoneKey) < 3 * 60 * 1e3) {
    return res.status(429).json({
      success: false,
      message: "H\u1EC7 th\u1ED1ng \u0111\xE3 nh\u1EADn \u0111\u01B0\u1EE3c y\xEAu c\u1EA7u c\u1EE7a b\u1EA1n, vui l\xF2ng kh\xF4ng g\u1EEDi l\u1EA1i li\xEAn t\u1EE5c."
    });
  }
  recentServerSubmissions.set(phoneKey, now);
  const leads = getStoredLeads();
  const config = getStoredConfig();
  const newLead = {
    ...leadData,
    id: leadData.id || `LEAD-${Math.floor(1e3 + Math.random() * 9e3)}`,
    createdAt: leadData.createdAt || (/* @__PURE__ */ new Date()).toLocaleString("vi-VN"),
    status: leadData.status || "new"
  };
  leads.unshift(newLead);
  saveStoredLeads(leads);
  let emailResult = { success: false, method: "none" };
  try {
    emailResult = await triggerEmailNotification(newLead, config.adminEmail || DEFAULT_ADMIN_EMAIL);
    console.log(`\u{1F4E7} Email delivery result for ${newLead.id}:`, emailResult);
  } catch (err) {
    console.error(`Email delivery error for ${newLead.id}:`, err);
    emailResult = { success: false, error: err?.message || "L\u1ED7i g\u1EEDi mail" };
  }
  return res.status(201).json({
    success: true,
    lead: newLead,
    emailResult,
    message: emailResult?.success ? "\u0110\xE3 l\u01B0u h\u1ED3 s\u01A1 th\xE0nh c\xF4ng & g\u1EEDi email th\xF4ng b\xE1o t\u1EDBi Qu\u1EA3n Tr\u1ECB Vi\xEAn!" : "\u0110\xE3 l\u01B0u h\u1ED3 s\u01A1 th\xE0nh c\xF4ng v\xE0o h\u1EC7 th\u1ED1ng qu\u1EA3n tr\u1ECB!"
  });
});
app.patch("/api/leads/:id", (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  const leads = getStoredLeads();
  const idx = leads.findIndex((l) => l.id === id);
  if (idx === -1) {
    return res.status(404).json({ success: false, message: "Kh\xF4ng t\xECm th\u1EA5y h\u1ED3 s\u01A1 kh\xE1ch h\xE0ng" });
  }
  leads[idx] = { ...leads[idx], ...updates };
  saveStoredLeads(leads);
  return res.json({ success: true, lead: leads[idx] });
});
app.delete("/api/leads/:id", (req, res) => {
  const { id } = req.params;
  let leads = getStoredLeads();
  const initialLength = leads.length;
  leads = leads.filter((l) => l.id !== id);
  if (leads.length === initialLength) {
    return res.status(404).json({ success: false, message: "Kh\xF4ng t\xECm th\u1EA5y h\u1ED3 s\u01A1 \u0111\u1EC3 x\xF3a" });
  }
  saveStoredLeads(leads);
  return res.json({ success: true, message: "\u0110\xE3 x\xF3a h\u1ED3 s\u01A1 th\xE0nh c\xF4ng" });
});
app.post("/api/leads/reset", (req, res) => {
  if (import_fs.default.existsSync(LEADS_FILE)) {
    import_fs.default.unlinkSync(LEADS_FILE);
  }
  initStorage();
  const leads = getStoredLeads();
  return res.json({ success: true, leads });
});
app.post("/api/leads/notify", async (req, res) => {
  const { lead, targetEmail = DEFAULT_ADMIN_EMAIL } = req.body;
  if (!lead || !lead.fullName || !lead.phone) {
    return res.status(400).json({ success: false, message: "D\u1EEF li\u1EC7u kh\xE1ch h\xE0ng kh\xF4ng h\u1EE3p l\u1EC7" });
  }
  const result = await triggerEmailNotification(lead, targetEmail);
  return res.json({
    success: result.success,
    message: result.success ? `\u0110\xE3 g\u1EEDi email th\xF4ng b\xE1o t\u1EDBi ${targetEmail}` : "Kh\xF4ng th\u1EC3 g\u1EEDi email t\u1EF1 \u0111\u1ED9ng",
    method: result.method
  });
});
app.post("/api/admin/reset-otp", async (req, res) => {
  const { email = DEFAULT_ADMIN_EMAIL, otp } = req.body;
  if (!otp) {
    return res.status(400).json({ success: false, message: "Thi\u1EBFu m\xE3 OTP" });
  }
  const recipient = email || DEFAULT_ADMIN_EMAIL;
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  const smtpHost = process.env.SMTP_HOST || "smtp.gmail.com";
  const smtpPort = Number(process.env.SMTP_PORT) || 587;
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; background: #fff; padding: 24px; border-radius: 12px; border: 1px solid #e2e8f0;">
      <h2 style="color: #065f46; margin-top: 0;">\u{1F510} M\xC3 X\xC1C TH\u1EF0C QU\u1EA2N TR\u1ECA VI\xCAN \u0110\u1EE8C H\u1EA2I FE</h2>
      <p>B\u1EA1n v\u1EEBa y\xEAu c\u1EA7u kh\xF4i ph\u1EE5c / \u0111\u1EB7t l\u1EA1i m\u1EADt kh\u1EA9u c\u1ED5ng Qu\u1EA3n tr\u1ECB Lead \u0110\u1EE9c H\u1EA3i FE.</p>
      <div style="background: #f1f5f9; padding: 16px; border-radius: 8px; text-align: center; margin: 20px 0;">
        <span style="font-size: 28px; font-weight: bold; letter-spacing: 6px; color: #047857;">${otp}</span>
      </div>
      <p style="font-size: 13px; color: #64748b;">M\xE3 n\xE0y c\xF3 hi\u1EC7u l\u1EF1c trong 15 ph\xFAt. N\u1EBFu b\u1EA1n kh\xF4ng y\xEAu c\u1EA7u, vui l\xF2ng b\u1ECF qua email n\xE0y.</p>
      <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
      <p style="font-size: 11px; color: #94a3b8;">H\u1EC7 th\u1ED1ng B\u1EA3o M\u1EADt \u0110\u1EE9c H\u1EA3i FE - T\u01B0 V\u1EA5n Vay T\xEDn Ch\u1EA5p</p>
    </div>
  `;
  if (smtpUser && smtpPass) {
    try {
      const transporter = import_nodemailer.default.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465,
        auth: { user: smtpUser, pass: smtpPass }
      });
      await transporter.sendMail({
        from: `"\u0110\u1EE9c H\u1EA3i FE Security" <${smtpUser}>`,
        to: recipient,
        subject: `[M\xC3 OTP: ${otp}] Kh\xF4i ph\u1EE5c m\u1EADt kh\u1EA9u qu\u1EA3n tr\u1ECB \u0110\u1EE9c H\u1EA3i FE`,
        html: htmlContent
      });
      return res.json({ success: true, message: "\u0110\xE3 g\u1EEDi OTP qua email" });
    } catch (err) {
      console.error("SMTP OTP error:", err);
    }
  }
  try {
    const formData = new URLSearchParams();
    formData.append("_subject", `[M\xC3 OTP: ${otp}] Kh\xF4i ph\u1EE5c m\u1EADt kh\u1EA9u qu\u1EA3n tr\u1ECB \u0110\u1EE9c H\u1EA3i FE`);
    formData.append("_replyto", recipient);
    formData.append("M\xE3 OTP Kh\xF4i Ph\u1EE5c", otp);
    formData.append("H\u1EA1n D\xF9ng", "15 Ph\xFAt");
    await fetch(`https://formsubmit.co/ajax/${encodeURIComponent(recipient)}`, {
      method: "POST",
      body: formData,
      headers: { Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" }
    });
  } catch (relayErr) {
    console.error("Relay OTP error:", relayErr);
  }
  return res.json({ success: true, message: "\u0110\xE3 ph\xE1t l\u1EC7nh g\u1EEDi OTP" });
});
app.get("/download-hosting-zip", (req, res) => {
  const zipPath = import_path.default.join(process.cwd(), "public", "vay365_hosting_cpanel.zip");
  if (import_fs.default.existsSync(zipPath)) {
    res.setHeader("Content-Disposition", 'attachment; filename="vay365_hosting_cpanel.zip"');
    res.setHeader("Content-Type", "application/zip");
    res.download(zipPath, "vay365_hosting_cpanel.zip");
  } else {
    res.status(404).send("File zip ch\u01B0a s\u1EB5n s\xE0ng");
  }
});
async function start() {
  initStorage();
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`\u{1F680} \u0110\u1EE9c H\u1EA3i FE server listening on http://0.0.0.0:${PORT}`);
    console.log(`\u{1F4E7} Admin Notification Email: ${DEFAULT_ADMIN_EMAIL}`);
  });
}
start();
//# sourceMappingURL=server.cjs.map
